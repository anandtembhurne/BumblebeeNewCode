package com.unotech.application;

import java.util.Scanner;

public class App1 {

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		PermissionTree perm = new PermissionTree();
//		int choice;
//		boolean status = false;
//		String workspace = null;
//		Scanner sc = new Scanner(System.in);
//		do {
//			System.out.println("Options");
//			System.out
//			.println("1: permission WORKSPACE");
//			System.out
//			.println("2: NAME OF USERS WITH NUMBER OF DOCUMENT AND SIZE IN WORKSPACE");
//			System.out.println("0: exit");
//			System.out.println("enter the options");
//			choice = sc.nextInt();
//			switch (choice) {
//
//			case 1:
//				System.out.println("Enter Id of Workspace");
//				 workspace = sc.next();
//				 perm.getPermissions(workspace);
//				System.out.println("Enter the path of csv file:");
//				if (status) {
//					System.out.println("work is done");
//				} else
//					System.out.println("error");
//				break;
//			case 2:
//				status = perm.workspaceDetails1();
//				if (status) {
//					System.out.println("data is available in csv");
//				} else {
//					System.out.println("error");
//				}
//				break;
//		
//			case 0:
//				break;
//
//			
//			default:
//				System.out.println("please enter correct option");
//				break;
//			}
//
//		} while (choice != 0);
//		sc.close();
//		System.out.println("Thank you!");
//		perm.connectionClose();
		System.out.println("hhhhhhhhhhhhhh");
	}
	
}
